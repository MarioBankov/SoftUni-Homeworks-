﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Linq;

namespace Stealer
{
    public class Spy
    {

        public string StealFieldInfo(string nameOfTheClass,params string[] filds)
        {
            var @namespece = "Stealer.";
            Type classType = Type.GetType(namespece+nameOfTheClass);

            FieldInfo[] classFields = classType.GetFields
               (BindingFlags.Static |
                BindingFlags.NonPublic | 
                BindingFlags.Public | 
                BindingFlags.Instance);

            StringBuilder sb = new StringBuilder();
            var parametersInfo = classType.GetConstructors().First().GetParameters();
            if (parametersInfo.Length==0)
            {

                var instance = Activator.CreateInstance(classType, null);
                sb.AppendLine($"Class under investigation: {nameOfTheClass}");
                foreach (var item in classFields.Where(x => filds.Contains(x.Name)))
                {
                    sb.AppendLine($"{item.Name} = {item.GetValue(instance)}");
                }
            }
            return sb.ToString().TrimEnd();
            
        }
    }
}
