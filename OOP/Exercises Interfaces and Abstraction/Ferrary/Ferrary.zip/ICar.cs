﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ferrary
{
    public interface ICar
    {

        string Brake();
        string Gas();

    }
}
