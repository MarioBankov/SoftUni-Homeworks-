﻿using System;
using System.Collections.Generic;

namespace PersonInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            List<Iindentable> numbers = new List<Iindentable>();
            while (true)
            {
                string[] data = Console.ReadLine().Split();
                if (data[0].ToLower()=="end")
                {
                    break;
                }
                if (data.Length==2)
                {
                    Robot r = new Robot(data[0], data[1]);
                    numbers.Add(r);
                }
                else
                {
                    Citizens c = new Citizens(data[0], int.Parse(data[1]), data[2]);
                    numbers.Add(c);
                }
            }
            string check = Console.ReadLine();
            foreach (var item in numbers)
            {
                if (item.Id.EndsWith(check))
                {
                    Console.WriteLine(item.Id);
                }
            }
        }
    }
}
